let userPurchase = document.getElementById('u1').value;
let pass = document.getElementById('p2').value;

let username = document.querySelector('.userName');
let password = document.querySelector('.userPass');

function submitForm() {
    username.append(user);
    password.append(pass);
}
