function confirmForm() {
    var password = document.forms["login"]["password"].value;
    var username = document.forms["login"]["username"].value;
    let p = document.querySelector(".output");
    const user = {
    username: "Tmax",
    password: "tmax123"
    }
    if (username == "") {
        p.appendChild = "Please provide your username!";
    }
    if (password == "") {
        p.no
         p.appendChild = "Please provide your password!";
        // alert(  );
    }
    if (username == user.username && password == user.password) {
         p.appendChild = "Login Sucessfully";
        // alert();
    }
    else {
         p.appendChild = "Invalid Login";
        // alert(");
    }   
}

